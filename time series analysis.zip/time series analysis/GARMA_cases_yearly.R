library(MASS)
library(ggplot2)
library(zoo)
library(lubridate)
library(dplyr)

# Load the data
data <- read.csv("ARMA.csv")

#################################################

# Basic line plot of your yearly data
ggplot(data, aes(x = Time, y = Cases)) +
  geom_line() +
  labs(title = "Yearly Disease Cases", x = "Year", y = "Cases") +
  theme_minimal()

# ACF plot
acf(data$Cases, main = "Autocorrelation of Yearly Cases")

# Fourier Transform
fft_result <- fft(data$Cases)
# Magnitude of the FFT
fft_magnitude <- Mod(fft_result)
# Plot the frequency components
plot(fft_magnitude, type = "h", main = "Fourier Transform of Yearly Cases",
     xlab = "Frequency", ylab = "Magnitude")

Box.test(data$Cases, type = "Ljung-Box", lag = 10)  # Test for lag 10


#######################################################

# Convert the Time column to numeric (for year data)
data$Time <- as.numeric(data$Time)

# Create a lagged variable for Cases (lag by 1 year)
data$Lag_Cases <- lag(data$Cases, 1)

# Ensure that the dataset does not have LST variable
# Fit the Negative Binomial model without LST and seasonality
model <- glm.nb(Cases ~ Lag_Cases, 
                data = data, na.action = na.exclude)

# Calculate the residuals from the initial model
data$residuals <- residuals(model, type = "deviance")

# Create a moving average term (e.g., MA(1))
data$MA1 <- lag(data$residuals, 1)

# Refit the model including the moving average (MA1) term
model <- glm.nb(Cases ~ Lag_Cases + MA1, 
                data = data, na.action = na.exclude)

# Display the summary of the model
summary(model)
AIC(model)
BIC(model)

# Extract the coefficients
coefficients <- coef(model)
print(coefficients)

# Generate predictions
data$Predicted <- predict(model, type = "response")

# Plot observed vs predicted cases for yearly data
ggplot(data, aes(x = Time)) + 
  geom_line(aes(y = Cases, color = "Observed")) + 
  geom_line(aes(y = Predicted, color = "Predicted")) + 
  labs(title = "Observed vs Predicted Disease Cases (Yearly)",
       x = "Year",
       y = "Number of Cases",
       color = "Legend") +
  theme_minimal()

# Forecasting future data
last_date <- max(data$Time)  # Find the last year in the data
future_dates <- seq(last_date + 1, by = 1, length.out = 10)  # Predict for next 10 years

# Create a data frame for future dates (10 years ahead)
future_data <- data.frame(
  Time = future_dates,
  Lag_Cases = NA,  # Placeholder for lagged cases
  MA1 = NA,  # Placeholder for moving average term
  residuals = NA  # Placeholder for residuals
)

# Predict future values iteratively using lag and MA terms
for (i in 1:nrow(future_data)) {
  # For the first forecasted point, use the last observed case count and residual
  future_data$Lag_Cases[i] <- ifelse(i == 1, tail(data$Cases, 1), future_data$Predicted[i-1])
  
  # For MA1, use the residuals from the last observed period for the first point
  future_data$MA1[i] <- ifelse(i == 1, tail(data$residuals, 1), future_data$residuals[i-1])
  
  # Generate prediction for the current future date
  prediction <- predict(model, newdata = future_data[i, ], type = "response", se.fit = TRUE)
  
  # Store the predicted value and standard error of fit
  future_data$Predicted[i] <- prediction$fit
  future_data$se.fit[i] <- prediction$se.fit
  
  # Simulate residuals for the next period based on the residuals' distribution
  future_data$residuals[i] <- rnorm(1, mean = 0, sd = sd(data$residuals, na.rm = TRUE))
}

# Convert Time columns to Date format in both data frames for consistency (if needed)
data$Time <- as.Date(as.yearmon(data$Time))
future_data$Time <- as.Date(as.yearmon(future_data$Time))  # Convert future Time to Date format

# Calculate confidence intervals for future predictions
future_data <- future_data %>%
  mutate(
    lower_CI = Predicted - 1.96 * se.fit,
    upper_CI = Predicted + 1.96 * se.fit
  )

# Combine observed and forecasted data for plotting
data_combined <- bind_rows(
  data %>% select(Time, Cases, Predicted) %>% mutate(lower_CI = NA, upper_CI = NA),
  future_data %>% select(Time, Predicted, lower_CI, upper_CI) %>% mutate(Cases = NA)
)

write.csv(data_combined,"forecasted_05 years.csv")

# Plot observed, predicted, and forecasted cases with confidence intervals
# ggplot(data_combined, aes(x = Time)) + 
#   geom_line(aes(y = Cases, color = "Observed"), na.rm = TRUE, size = 1) + 
#   geom_line(aes(y = Predicted, color = "Predicted"), na.rm = TRUE, size = 1) + 
#   geom_ribbon(data = future_data, aes(ymin = lower_CI, ymax = upper_CI, fill = "Confidence Interval"), alpha = 0.2) + 
#   geom_line(data = future_data, aes(y = Predicted, color = "Forecasted"), size = 1) +
#   labs(title = "Observed, predicted and forecasted disease cases on yearly basis",
#        x = "Year",
#        y = "Number of Cases") +
#   scale_color_manual(values = c("Observed" = "orange2", 
#                                 "Predicted" = "skyblue3", 
#                                 "Forecasted" = "red"),
#                      breaks = c("Observed", "Predicted", "Forecasted")) +
#   scale_fill_manual(values = c("Confidence Interval" = "blue")) +
#   theme_minimal() +
#   theme(legend.title = element_blank())  # Remove legend title


plot <- ggplot(data_combined, aes(x = Time)) + 
  geom_line(aes(y = Cases, color = "Observed"), na.rm = TRUE, size = 1.5) + 
  geom_line(aes(y = Predicted, color = "Predicted"), na.rm = TRUE, size = 1.5) + 
  geom_ribbon(data = future_data, aes(ymin = lower_CI, ymax = upper_CI, fill = "Confidence Interval"), alpha = 0.2) + 
  geom_line(data = future_data, aes(y = Predicted, color = "Forecasted"), size = 1.5) +
  labs(title = "Observed, Predicted, and Forecasted Disease Cases on Yearly Basis",
       x = "Year",
       y = "Number of Cases") +
  scale_color_manual(values = c("Observed" = "orange2", 
                                "Predicted" = "skyblue3", 
                                "Forecasted" = "red"),
                     breaks = c("Observed", "Predicted", "Forecasted")) +
  scale_fill_manual(values = c("Confidence Interval" = "blue")) +
  theme_classic() +  # Removes the plot border and grid lines
  theme(
    legend.title = element_blank(),               # Remove legend title
    axis.title = element_text(size = 14),         # Increase axis title font size
    axis.text = element_text(size = 14),          # Increase axis text font size
    axis.line = element_line(size = 1)          # Thicker x and y axis lines
  )
ggsave("high_quality_plot_2.png", plot = plot, width = 15, height = 8, dpi = 300)
